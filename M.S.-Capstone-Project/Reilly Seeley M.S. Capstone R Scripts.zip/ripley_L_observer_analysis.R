####################################################################################
################### Ripley L-function Envelopes by Observer Type ###################
####################################################################################

# 1. Reads cleaned observations, converts to UTM Zone 13N spatial points, and splits by observer type.
# 2. Transforms each group into a spatstat point pattern (ppp).
# 3. Computes Ripley’s L-function envelopes at 5 km and 20 km scales for each group.
# 4. Plots and saves four envelope graphs (neighborhood vs. urban for standard and super observers).

# Load data
observations <- read_csv("cleaned_observations.csv")

# Convert to spatial data (UTM Zone 13N)
obs_sf <- st_as_sf(observations, coords = c("longitude", "latitude"), crs = 4326)
obs_sf_proj <- st_transform(obs_sf, 32613)

# Subset data by observer type
standard_sf <- obs_sf_proj %>% filter(status == "standard-observer")
super_sf <- obs_sf_proj %>% filter(status == "super-observer")

# Convert to spatstat format (ppp)
standard_ppp <- as.ppp(st_coordinates(standard_sf), W=as.owin(st_bbox(obs_sf_proj)))
super_ppp <- as.ppp(st_coordinates(super_sf), W=as.owin(st_bbox(obs_sf_proj)))

set.seed(123)

# Function to create L-function envelope data
get_L_envelope_df <- function(ppp_data, r_max) {
  env <- envelope(ppp_data, fun=Lest, nsim=99, rmax=r_max, correction="Ripley", verbose=FALSE)
  data.frame(r=env$r, obs=env$obs, theo=env$theo, lo=env$lo, hi=env$hi)
}

# Plot L-function envelope with ggplot
plot_L_envelope <- function(df, group_label, scale_label, filename) {
  p <- ggplot(df, aes(x=r)) +
    geom_ribbon(aes(ymin=lo, ymax=hi), fill="gray70", alpha=0.6) +
    geom_line(aes(y=obs), color="blue", linewidth=1) +
    geom_line(aes(y=theo), color="black", linetype="dashed") +
    labs(title=paste("Ripley's L Envelope -", group_label, scale_label),
         x="Distance (m)",
         y="L(r)") +
    theme_bw(base_size=14)
  
  ggsave(filename, plot=p, width=8, height=6, dpi=300)
}

# Neighborhood scale (5 km)
standard_neigh_L <- get_L_envelope_df(standard_ppp, 5000)
super_neigh_L <- get_L_envelope_df(super_ppp, 5000)

plot_L_envelope(standard_neigh_L, "Standard Observers", "(Neighborhood 5 km)", 
                "standard_observers_neighborhood_L.png")

plot_L_envelope(super_neigh_L, "Super Observers", "(Neighborhood 5 km)", 
                "super_observers_neighborhood_L.png")

# Urban scale (20 km)
standard_urban_L <- get_L_envelope_df(standard_ppp, 20000)
super_urban_L <- get_L_envelope_df(super_ppp, 20000)

plot_L_envelope(standard_urban_L, "Standard Observers", "(Urban 20 km)", 
                "standard_observers_urban_L.png")

plot_L_envelope(super_urban_L, "Super Observers", "(Urban 20 km)", 
                "super_observers_urban_L.png")
