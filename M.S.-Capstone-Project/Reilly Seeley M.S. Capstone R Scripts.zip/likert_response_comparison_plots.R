####################################################################################
############# Comparative Likert Response Boxplots by Observer Status ##############
####################################################################################

# 1. Reads in survey responses and assigns Observer_Status.
# 2. Pivots statement columns into long format and converts responses to numeric.
# 3. Joins full statement text for readability.
# 4. Loops through each statement to build and save box-and-jitter comparative plots.

# Import data
responses <- read.csv("ResponseData_Edited.csv", stringsAsFactors = FALSE)

# Assign Observer Status explicitly based on Collector_ID
responses <- responses %>%
  mutate(Observer_Status = case_when(
    Collector_ID == 433931884 ~ "Super",
    Collector_ID == 433931340 ~ "Standard",
    TRUE ~ "Unknown"
  ))

responses_long <- responses %>%
  pivot_longer(
    cols = starts_with("Statement_"),
    names_to = "Statement",
    values_to = "Response"
  ) %>%
  filter(!is.na(Response), Response != "")

# Verify
head(responses_long)

# Define Likert scale 
likert_scale <- c(
  "Strongly Disagree" = 1,
  "Disagree" = 2,
  "Disagree somewhat" = 3,
  "Neither agree nor disagree" = 4,
  "Agree somewhat" = 5,
  "Agree" = 6,
  "Strongly Agree" = 7
)

# Convert responses 
responses_long <- responses_long %>%
  mutate(Response_Numeric = likert_scale[Response])

# Check conversion 
head(responses_long)

# Create a data frame to hold statement texts
statement_text <- data.frame(
  Statement = paste0("Statement_", 1:24),
  Statement_Text = c(
    "I have gained new knowledge about the project content since discovering MROS",
    "My work combined with other observers makes a meaningful impact in MROS research",
    "I can personally achieve something through my work with MROS",
    "I am satisfied with how MROS has increased or sustained my interest in science",
    "I have acquired new scientific skills since becoming involved with MROS",
    "I am interested in applying scientific knowledge or methods related to MROS in my own personal work beyond my participation in data collection",
    "My attitude towards the science has changed, allowing me to have more trust in the scientific process since becoming involved with MROS",
    "I am motivated to participate in this project long-term",
    "I wish to communicate with other MROS users regarding data collection",
    "I am able to explain the MROS mission and my role in it",
    "I am aware of MROS-related publications",
    "MROS has helped me understand how scientific results are generated",
    "I am satisfied with the amount of input I receive from MROS on their work with citizen science data",
    "I wish to receive more updates on the results of MROS research (e.g., new report-backs, summaries of research, etc.)",
    "I am satisfied with the report-backs for observers on the MROS website and feel they are good resources for learning about the project",
    "I am satisfied with the amount of recognition I receive for my work as a citizen scientist through MROS",
    "My involvement in MROS or climate change-focused participatory science programs makes me feel like I am part of a larger environmental stewardship movement",
    "I wish to know more about how MROS project results have a role in political and societal decision-making processes",
    "I wish there was a competitive component to data collection, like a public leaderboard display through the year",
    "My involvement with MROS has helped me better understand the local environment and its relationship to the larger climate system",
    "I trust that data collected at a local scale can effectively inform decisions at broader scales (e.g., regional, national)",
    "The Rocky Mountains are the headwaters for major river systems that impact multiple regions in the U.S., including the Colorado, Missouri, and Columbia Rivers. I am aware of how these river systems contribute to water supply and environmental health beyond the Rocky Mountain region",
    "My involvement with MROS has made me feel more connected to the environmental conditions (such as rain and snow) that impact the Rocky Mountain region and contribute to the greater climate system",
    "I care about these environmental factors because they affect my local community"
  )
)

# Join these statements with response data
responses_long <- responses_long %>%
  left_join(statement_text, by = "Statement")

for (stmt in unique(responses_long$Statement_Text)) {
  
  plot_data <- responses_long %>%
    filter(Statement_Text == stmt, Observer_Status %in% c("Super", "Standard"))
  
  # Automatically wrap long titles
  wrapped_stmt <- str_wrap(stmt, width = 80)  # Adjust 'width' as needed
  
  p <- ggplot(plot_data, aes(x = Observer_Status, y = Response_Numeric, fill = Observer_Status)) +
    geom_boxplot(alpha = 0.6, outlier.shape = NA) +
    geom_jitter(aes(color = Observer_Status), width = 0.15, alpha = 0.8, size = 1.5) +
    scale_y_continuous(breaks = 1:7, labels = names(likert_scale)) +
    labs(title = wrapped_stmt,
         x = "Observer Status",
         y = "Likert Response",
         fill = "Observer Status",
         color = "Observer Status") +
    theme_minimal(base_size = 12) +
    theme(
      legend.position = "bottom",
      plot.title = element_text(hjust = 0.5, size = 12, face = "bold"),
      axis.text.y = element_text(size = 8),
      panel.background = element_rect(fill = "white", color = NA),  # Explicit white background
      plot.background = element_rect(fill = "white", color = NA)    # Explicit white background
    )
  
  # Ensure filenames are safe and readable
  filename <- paste0(gsub("[^a-zA-Z0-9]", "_", substr(stmt, 1, 40)), "_comparative_plot.png")
  
  ggsave(filename, plot = p, width = 10, height = 6, dpi = 300, bg = "white")
}


