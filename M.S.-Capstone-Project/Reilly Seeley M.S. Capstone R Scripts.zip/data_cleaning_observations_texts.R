####################################################################################
###################### Data Cleaning: Observations & Text Logs #####################
####################################################################################

# 1. Reads raw observation and text CSVs.
# 2. Selects relevant columns and combines local date & time into datetime_submitted.
# 3. Filters text log to the Rocky Mountains of Colorado and parses send_datetime.
# 4. Writes cleaned observations and texts to cleaned_observations.csv and cleaned_texts_co.csv.

# Load observations
observations <- read_csv("observations_2024.csv")

# Inspect data
head(observations)

# Select necessary columns
observations <- observations %>%
  select(phase, user_ID, latitude, longitude, status, time_submitted_local, date_submitted_local)

# Convert date and time into proper formats
observations <- observations %>%
  mutate(
    datetime_submitted = mdy(date_submitted_local) + hms(time_submitted_local)
  ) %>%
  select(-time_submitted_local, -date_submitted_local)

head(observations)

# Load the text messages CSV
texts <- read_csv("text_log.csv")

# Inspect data
head(texts)

# Filter for Rocky Mountains of Colorado region only
texts_co <- texts %>%
  filter(region == "Rocky Mountains of Colorado")

# Convert sendDate into proper datetime format
texts_co <- texts_co %>%
  mutate(send_datetime = ymd_hms(sendDate, tz = "UTC")) %>%
  select(-sendDate)

head(texts_co)

write_csv(observations, "cleaned_observations.csv")
write_csv(texts_co, "cleaned_texts_co.csv")


