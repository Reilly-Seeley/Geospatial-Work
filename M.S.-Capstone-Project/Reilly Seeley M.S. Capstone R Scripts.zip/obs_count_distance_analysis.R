####################################################################################
################ Observation Count vs. Home-Proxy Distance Analysis ################
####################################################################################

# 1. Reads in cleaned observations and home-proxy locations; computes each user’s total observations and average Haversine distance from home.
# 2. Creates a scatterplot of observation count vs. average distance and a violin+boxplot of average distance (log scale) by observer status.
# 3. Saves the scatterplot to obs_count_vs_distance_plot.png and the violin plot to observer_avg_distance_violin_plot.png.

# Load datasets
observations <- read_csv("cleaned_observations.csv")
home_locations <- read_csv("home_proxy_locations.csv")

# Calculate observation count per user
obs_count <- observations %>%
  group_by(user_ID, status) %>%
  summarise(num_obs = n(), .groups = 'drop')

# Calculate distances from home proxy for each observation
obs_distances <- observations %>%
  left_join(home_locations, by = "user_ID", suffix = c("_obs", "_home")) %>%
  mutate(dist_from_home = distHaversine(
    cbind(longitude_obs, latitude_obs), 
    cbind(longitude_home, latitude_home)
  ))

# Calculate average distance from home per user and preserve 'status'
avg_distances <- obs_distances %>%
  left_join(observations %>% select(user_ID, status), by = "user_ID") %>% 
  group_by(user_ID, status) %>%
  summarise(avg_distance = mean(dist_from_home, na.rm = TRUE), .groups = 'drop')

# Combine datasets for scatterplot
combined_data <- obs_count %>%
  left_join(avg_distances, by = c("user_ID", "status"))

# Original scatterplot
scatter_plot <- ggplot(combined_data, aes(x = num_obs, y = avg_distance, color = status)) +
  geom_point(size = 2, alpha = 0.7) +
  labs(x = "Number of Observations per User",
       y = "Average Distance from Home Location (m)",
       title = "Observation Count v. Average Distance from Home-Proxy",
       color = "Observer Status") +
  theme_bw(base_size = 14) +
  theme(legend.position = "right",
        axis.title = element_text(face = "bold"),
        axis.text = element_text(face = "bold"),
        plot.title = element_text(face = "bold", hjust = 0.5))

# Violin plot with embedded boxplot and log-transformed y-axis
violin_plot <- ggplot(avg_distances, aes(x = status, y = avg_distance, fill = status)) +
  geom_violin(trim = FALSE, alpha = 0.7) +
  geom_boxplot(width = 0.15, color = "black", alpha = 0.8) +
  scale_fill_manual(values = c("#F8766D", "#00BFC4")) +
  scale_y_log10() +
  labs(x = "Observer Status",
       y = "Log of Average Distance from Home Location (m)",
       title = "Average Distance from Home by Observer Group (Log Scale)") +
  theme_bw(base_size = 16) +
  theme(
    legend.position = "none",
    axis.title = element_text(face = "bold"),
    axis.text = element_text(face = "bold"),
    plot.title = element_text(face = "bold", hjust = 0.5)
  )

# Save plots to files
ggsave("obs_count_vs_distance_plot.png", scatter_plot, width = 12, height = 8, dpi = 300)
ggsave("observer_avg_distance_violin_plot.png", violin_plot, width = 10, height = 8, dpi = 300)