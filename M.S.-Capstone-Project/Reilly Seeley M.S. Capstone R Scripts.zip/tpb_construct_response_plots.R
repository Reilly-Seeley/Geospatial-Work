####################################################################################
################## TPB Construct Response Plots by Observer Group ##################
####################################################################################

# 1. Reads survey responses, assigns Observer_Group, pivots statements into long format, and converts to numeric Likert scores.
# 2. Maps each statement to its TPB construct and filters out missing values.
# 3. Generates and saves a boxplot of numeric responses by TPB construct and observer group (TPB_BoxPlot.png).
# 4. Generates and saves a violin plot (with embedded boxplots) by TPB construct and observer group (TPB_ViolinPlot.png).

# Load the dataset
data <- read.csv("ResponseData_Edited.csv")

# Convert the observer group to categorical
data$Observer_Group <- ifelse(data$Collector_ID == 433931884, "Super", "Standard")

# Reshape data into long format
long_data <- data %>%
  pivot_longer(cols = starts_with("Statement_"),
               names_to = "Statement",
               values_to = "Response") %>%
  mutate(Response_Numeric = case_when(
    Response == "Strongly Agree" ~ 1,
    Response == "Agree" ~ 2,
    Response == "Agree somewhat" ~ 3,
    Response == "Neither agree nor disagree" ~ 4,
    Response == "Disagree somewhat" ~ 5,
    Response == "Disagree" ~ 6,
    Response == "Strongly Disagree" ~ 7,
    TRUE ~ NA_real_
  ))

# TPB Constructs mapping
tpb_constructs <- list(
  "Attitude Toward Behavior" = c("Statement_1", "Statement_4", "Statement_7", "Statement_12", "Statement_17"),
  "Subjective Norms and Social Influence" = c("Statement_9", "Statement_10", "Statement_11", "Statement_18", "Statement_19"),
  "Perceived Behavioral Control" = c("Statement_3", "Statement_5", "Statement_6", "Statement_20", "Statement_21"),
  "Behavioral Intention" = c("Statement_2", "Statement_8", "Statement_22", "Statement_23", "Statement_24")
)

# Map statements to TPB construct
long_data <- long_data %>%
  mutate(TPB_Construct = case_when(
    Statement %in% tpb_constructs[["Attitude Toward Behavior"]] ~ "Attitude Toward Behavior",
    Statement %in% tpb_constructs[["Subjective Norms and Social Influence"]] ~ "Subjective Norms and Social Influence",
    Statement %in% tpb_constructs[["Perceived Behavioral Control"]] ~ "Perceived Behavioral Control",
    Statement %in% tpb_constructs[["Behavioral Intention"]] ~ "Behavioral Intention",
    TRUE ~ NA_character_
  )) %>% 
  filter(!is.na(TPB_Construct) & !is.na(Response_Numeric))

# Box Plot Visualization
box_plot <- ggplot(long_data, aes(x = TPB_Construct, y = Response_Numeric, fill = Observer_Group)) +
  geom_boxplot(alpha = 0.7, position = position_dodge(width = 0.8)) +
  scale_y_reverse(breaks = 1:7, labels = c("Strongly Agree","Agree","Agree Somewhat","Neutral",
                                           "Disagree Somewhat","Disagree","Strongly Disagree")) +
  labs(title = "Box Plot of TPB Constructs by Observer Group",
       x = "TPB Construct",
       y = "Likert Response") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# Save box plot as PNG
ggsave("TPB_BoxPlot.png", plot = box_plot, width = 10, height = 6, dpi = 300)

# Violin Plot Visualization
violin_plot <- ggplot(long_data, aes(x = TPB_Construct, y = Response_Numeric, fill = Observer_Group)) +
  geom_violin(alpha = 0.7, position = position_dodge(width = 0.8), trim = FALSE) +
  geom_boxplot(width = 0.1, position = position_dodge(width = 0.8)) +
  scale_y_reverse(breaks = 1:7, labels = c("Strongly Agree","Agree","Agree Somewhat","Neutral",
                                           "Disagree Somewhat","Disagree","Strongly Disagree")) +
  labs(title = "Violin Plot of TPB Constructs by Observer Group",
       x = "TPB Construct",
       y = "Likert Response") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# Save violin plot as PNG
ggsave("TPB_ViolinPlot.png", plot = violin_plot, width = 10, height = 6, dpi = 300)
