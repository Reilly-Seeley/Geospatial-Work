####################################################################################
########################## Home-Proxy Submission Analysis ##########################
####################################################################################

# 1. Identifies each user’s most frequent (and earliest) reporting location as their home-proxy and saves it to home_proxy_locations.csv.
# 2. Calculates and plots the average % of submissions from home for all users and again excluding single‐submission users, saving two bar charts.
# 3. Computes and plots the distribution of submission counts for standard observers, saving a PDF of the frequency distribution.

# Load data
submissions <- read.csv("cleaned_observations.csv")

# Identify home-proxy location for each user_ID
home_proxy_df <- submissions %>%
  group_by(user_ID, latitude, longitude, status) %>%
  summarise(report_count = n(), first_report = min(ymd_hms(datetime_submitted))) %>%
  ungroup() %>%
  group_by(user_ID) %>%
  arrange(desc(report_count), first_report) %>%
  slice(1) %>%
  select(user_ID, status, latitude, longitude)

# Save home-proxy table
write.csv(home_proxy_df, "home_proxy_locations.csv", row.names = FALSE)

# Calculate submissions from home-proxy location
submissions_home <- submissions %>%
  left_join(home_proxy_df, by = "user_ID") %>%
  mutate(home_submission = ifelse(latitude.x == latitude.y & longitude.x == longitude.y, 1, 0)) %>%
  group_by(user_ID, status.x) %>%
  summarise(percent_home_submissions = mean(home_submission) * 100)

# Average percentage bar chart by observer group
avg_home_plot <- submissions_home %>%
  group_by(status.x) %>%
  summarise(avg_percent_home = mean(percent_home_submissions)) %>%
  ggplot(aes(x = status.x, y = avg_percent_home, fill = status.x)) +
  geom_bar(stat = "identity", position = position_dodge()) +
  geom_text(aes(label = paste0(round(avg_percent_home, 1), "%")), vjust = -0.25, size = 3) +
  scale_fill_manual(values = c("standard-observer" = "red", "super-observer" = "turquoise")) +
  labs(title = "Average % of Submissions from Home-Proxy Location",
       x = "Observer Type",
       y = "% of Submissions",
       fill = "Observer Type") +
  theme_bw() +
  theme(panel.background = element_rect(fill = "white"),
        plot.background = element_rect(fill = "white"))

ggsave("average_home_proxy_submissions.png", avg_home_plot, width = 8, height = 6)

# Exclude users with only 1 submission
submissions_filtered <- submissions %>%
  group_by(user_ID) %>%
  filter(n() > 1)

# Calculate again for filtered data
submissions_home_filtered <- submissions_filtered %>%
  left_join(home_proxy_df, by = "user_ID") %>%
  mutate(home_submission = ifelse(latitude.x == latitude.y & longitude.x == longitude.y, 1, 0)) %>%
  group_by(user_ID, status.x) %>%
  summarise(percent_home_submissions = mean(home_submission) * 100)

# Bar chart excluding single submissions
avg_home_filtered_plot <- submissions_home_filtered %>%
  group_by(status.x) %>%
  summarise(avg_percent_home = mean(percent_home_submissions)) %>%
  ggplot(aes(x = status.x, y = avg_percent_home, fill = status.x)) +
  geom_bar(stat = "identity", position = position_dodge()) +
  geom_text(aes(label = paste0(round(avg_percent_home, 1), "%")), vjust = -0.25, size = 3) +
  scale_fill_manual(values = c("standard-observer" = "red", "super-observer" = "turquoise")) +
  labs(title = "Avg % Home-Proxy Submissions (Excluding Single Submissions)",
       x = "Observer Type",
       y = "% of Submissions",
       fill = "Observer Type") +
  theme_bw() +
  theme(panel.background = element_rect(fill = "white"),
        plot.background = element_rect(fill = "white"))

ggsave("filtered_home_proxy_submissions.png", avg_home_filtered_plot, width = 8, height = 6)

# Standard observer submission frequency distribution
standard_freq_plot <- submissions %>%
  filter(status == "standard-observer") %>%
  group_by(user_ID) %>%
  summarise(submission_count = n()) %>%
  group_by(submission_count) %>%
  summarise(num_users = n()) %>%
  mutate(percent_users = (num_users / sum(num_users)) * 100) %>%
  ggplot(aes(x = submission_count, y = percent_users)) +
  geom_bar(stat = "identity", fill = "red") +
  labs(title = "% of Standard Observers by Submission Count",
       x = "Number of Submissions",
       y = "% of Observers") +
  theme_bw() +
  theme(panel.background = element_rect(fill = "white"),
        plot.background = element_rect(fill = "white"))

ggsave("standard_observer_submission_distribution.png", standard_freq_plot, width = 8, height = 6)
