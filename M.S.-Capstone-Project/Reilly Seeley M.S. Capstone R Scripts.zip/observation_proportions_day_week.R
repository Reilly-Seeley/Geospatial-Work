####################################################################################
#################### Observation Proportions by Day & Week Type ####################
####################################################################################

# 1. Reads cleaned observations, parses datetimes, and tags each record with day-of-week and weekday/weekend.
# 2. Calculates and plots the proportion of observations by observer type for each weekday and for weekday vs. weekend, saving two bar charts.
# 3. Exports the weekday/weekend summary table to weekday_weekend_summary.csv.

# Load data from CSV
data <- read.csv("cleaned_observations.csv")

# Convert datetime column to date-time object
data$datetime <- ymd_hms(data$datetime)

# Add a column for day of the week
data$day_of_week <- wday(data$datetime, label = TRUE, week_start = 1)

# Calculate proportions by observer type and day
prop_data <- data %>%
  group_by(status, day_of_week) %>%
  summarise(count = n()) %>%
  group_by(status) %>%
  mutate(proportion = count / sum(count),
         percentage = round(100 * proportion, 1))

# Rename observer types for clarity in legend
prop_data$status <- recode(prop_data$status, "standard-observer" = "Standard Observers", 
                           "super-observer" = "Super Observers")

# Create and save bar graph with percentages inside bars
plot <- ggplot(prop_data, aes(x = day_of_week, y = proportion, fill = status)) +
  geom_bar(stat = "identity", position = position_dodge()) +
  geom_text(aes(label = paste0(percentage, "%")),
            position = position_dodge(width = 0.9), vjust = -0.25, size = 3) +
  scale_fill_manual(values = c("Standard Observers" = "red", "Super Observers" = "turquoise")) +
  labs(title = "Proportion of Observations by Day of the Week",
       x = "Day of the Week",
       y = "Proportion of Observations",
       fill = "Observer Type") +
  theme_bw() +
  theme(panel.background = element_rect(fill = "white"),
        plot.background = element_rect(fill = "white"))

ggsave("proportion_observations_by_day.png", plot, width = 8, height = 6)

# Weekday vs. Weekend analysis
weekend_days <- c("Sat", "Sun")
data$weekday_weekend <- ifelse(data$day_of_week %in% weekend_days, "Weekend", "Weekday")

weekday_weekend_summary <- data %>%
  group_by(status, weekday_weekend) %>%
  summarise(count = n()) %>%
  group_by(status) %>%
  mutate(percentage = round(100 * count / sum(count), 2))

# Rename observer types for clarity in legend
weekday_weekend_summary$status <- recode(weekday_weekend_summary$status, "standard-observer" = "Standard Observers", 
                                         "super-observer" = "Super Observers")

# Create and save weekday vs weekend bar chart
weekend_plot <- ggplot(weekday_weekend_summary, aes(x = weekday_weekend, y = percentage, fill = status)) +
  geom_bar(stat = "identity", position = position_dodge()) +
  geom_text(aes(label = paste0(percentage, "%")), 
            position = position_dodge(width = 0.9), vjust = -0.25, size = 3) +
  scale_fill_manual(values = c("Standard Observers" = "red", "Super Observers" = "turquoise")) +
  labs(title = "Percentage of Observations: Weekday vs Weekend",
       x = "",
       y = "Percentage of Observations",
       fill = "Observer Type") +
  theme_bw() +
  theme(panel.background = element_rect(fill = "white"),
        plot.background = element_rect(fill = "white"))

ggsave("weekday_weekend_percentage.png", weekend_plot, width = 8, height = 6)

# Save the weekday vs weekend percentage table
write.csv(weekday_weekend_summary, "weekday_weekend_summary.csv", row.names = FALSE)
