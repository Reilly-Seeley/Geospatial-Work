####################################################################################
############ Daily Submissions by Observer Status with Text Annotations ############
####################################################################################

# 1. Reads in cleaned submission and text-send logs.
# 2. Aggregates daily counts by status (standard vs. super).
# 3. Plots time-series lines, overlays dashed lines on each reminder date,
#    and adds a secondary axis labeling those dates.
# 4. Saves output to daily_submission_rates.png.

# Load data
submissions <- read.csv("cleaned_observations.csv")
texts <- read.csv("MRoS_texts_CO.csv")

# Convert datetime columns to date format
submissions$datetime_submitted <- as.Date(submissions$datetime_submitted)

# Fix sendDate with manual entry (MM/DD/YY format)
texts <- texts[1:12, ]  # keep only first 12 rows to match manually entered dates
texts$sendDate <- as.Date(c("11/21/23", "12/26/23", "01/05/24", "02/02/24",
                            "02/09/24", "03/03/24", "03/13/24", "04/19/24",
                            "05/07/24", "10/30/24", "11/05/24", "11/08/24"),# • Reads in cleaned submission and text-send logs.
# • Aggregates daily counts by status (standard vs. super).
# • Plots time-series lines, overlays dashed lines on each reminder date,
#   and adds a secondary axis labeling those dates.
# • Saves output to daily_submission_rates.png.
                          format = "%m/%d/%y")

# Create daily submissions dataframe
daily_submissions <- submissions %>%
  group_by(datetime_submitted, status) %>%
  summarise(submissions = n()) %>%
  ungroup()

# Ensure 'status' is a factor
daily_submissions$status <- factor(daily_submissions$status,
                                   levels = c("standard-observer", "super-observer"))

# Custom labels with adjusted horizontal spacing
custom_labels <- format(texts$sendDate, "%m/%d/%y")

# Adjust breaks for specific dates to avoid overlap
adjusted_breaks <- texts$sendDate
adjusted_breaks[texts$sendDate == as.Date("10/30/24", format = "%m/%d/%y")] <- 
  adjusted_breaks[texts$sendDate == as.Date("10/30/24", format = "%m/%d/%y")] - 3

adjusted_breaks[texts$sendDate == as.Date("11/08/24", format = "%m/%d/%y")] <- 
  adjusted_breaks[texts$sendDate == as.Date("11/08/24", format = "%m/%d/%y")] + 5

# Plot data
p <- ggplot(daily_submissions, aes(x = datetime_submitted, y = submissions, color = status, group = status)) +
  geom_line(size = 1) +
  scale_color_manual(values = c("standard-observer" = "red", "super-observer" = "blue"),
                     labels = c("Standard Observers", "Super Observers")) +
  labs(title = "Daily Submission Rates by Observer Status",
       y = "Number of Submissions",
       x = "Date",
       color = "Observer Status") +
  theme_bw(base_size = 14) +
  theme(legend.position = "right",
        axis.title = element_text(face = "bold"),
        axis.text = element_text(face = "bold"),
        plot.title = element_text(face = "bold", hjust = 0.5))

# Add vertical dashed lines for text dates
for(date in texts$sendDate) {
  p <- p + geom_vline(xintercept = as.numeric(date), color = "gray60", linetype = "dashed")
}

# Add dual x-axis with bold formatting and increased font size, adjusting breaks
p <- p + scale_x_date(
  date_breaks = "1 month",
  date_labels = "%b %Y",
  sec.axis = dup_axis(
    breaks = adjusted_breaks,
    labels = custom_labels,
    name = "MRoS Text Dates"
  )
) +
  theme(
    axis.text.x.top = element_text(angle = 45, hjust = 0, size = 14, face = "bold"),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 14, face = "bold")
  )

# Save plot
ggsave("daily_submission_rates.png", plot = p, width = 18, height = 8, dpi = 300)