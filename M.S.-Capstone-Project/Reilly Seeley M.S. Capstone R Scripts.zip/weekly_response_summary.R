####################################################################################
################ Weekly Observer Response Rates with Reminder Flags ################
####################################################################################

# 1. Reads cleaned observations and reminder-text logs, bins submissions and texts into calendar weeks.
# 2. Calculates weekly unique-user submission counts and converts to response rates (%) by observer status.
# 3. Flags weeks with reminders and merges this indicator into the weekly rates.
# 4. Prints and exports the weekly summary table to weekly_summary_table.csv.

# Load datasets
submissions <- read_csv("cleaned_observations.csv")
texts <- read_csv("cleaned_texts_co.csv")

submissions <- submissions %>%
  mutate(week = floor_date(datetime_submitted, unit = "week")) %>%
  select(user_ID, status, week)

# Prepare texts data
texts <- texts %>%
  filter(region == "Rocky Mountains of Colorado") %>%
  mutate(datetime_sent = ymd_hms(send_datetime),
         week = floor_date(datetime_sent, unit = "week")) %>%
  select(week) %>%
  distinct()

# Compute weekly submission counts
weekly_submissions <- submissions %>%
  group_by(status, week) %>%
  summarise(total_submissions = n_distinct(user_ID), .groups = "drop")

# Compute weekly response rates (percentage)
total_observers <- submissions %>%
  distinct(user_ID, status) %>%
  count(status, name = "total_observers")

weekly_response_rates <- weekly_submissions %>%
  left_join(total_observers, by = "status") %>%
  mutate(response_rate = (total_submissions / total_observers) * 100)

# Merge with texts data to indicate weeks with reminders
weekly_summary <- weekly_response_rates %>%
  left_join(texts %>% mutate(reminder_sent = TRUE), by = "week") %>%
  replace_na(list(reminder_sent = FALSE))

# View the descriptive table
print(weekly_summary)

# Export the table explicitly to working directory
write_csv(weekly_summary, file.path(getwd(), "weekly_summary_table.csv"))

