####################################################################################
############# Weekly Total Submissions with Text-Reminder Annotations ##############
####################################################################################

# 1. Reads cleaned submissions, filters to 11/21/2023–12/10/2024, and aggregates weekly total submissions by observer status.
# 2. Manually defines reminder-text dates, adjusts label positions, and overlays dashed lines at those dates.
# 3. Plots colored line-plus-point time series with a secondary top axis showing text-send dates.
# 4. Saves the annotated weekly plot to weekly_total_submissions_filtered.png.

# Load submissions data
submissions <- read_csv("cleaned_observations.csv") %>%
  mutate(datetime_submitted = ymd_hms(datetime_submitted))

# Define date range
start_date <- ymd("2023-11-21", tz = "America/Denver")
end_date <- ymd("2024-12-10", tz = "America/Denver")

# Aggregate total submissions by week and observer status
weekly_total <- submissions %>%
  mutate(week = floor_date(datetime_submitted, unit = "week")) %>%
  filter(week >= start_date, week <= end_date) %>%
  group_by(week, status) %>%
  summarise(total_submissions = n(), .groups = "drop")

# Manually define text alert dates, explicitly including previously missing dates
manual_text_dates <- as_datetime(c(
  "2023-12-26", "2024-01-05", "2024-02-02", "2024-02-09", 
  "2024-03-03", "2024-03-13", "2024-04-19", "2024-05-07", 
  "2024-10-30", "2024-11-05", "2024-11-08"
), tz = "America/Denver")

# Adjust spacing for top axis labels
adjusted_text_breaks <- manual_text_dates
adjusted_text_breaks[length(adjusted_text_breaks)] <- adjusted_text_breaks[length(adjusted_text_breaks)] + hours(36)

# Weekly Plot
weekly_plot_total <- ggplot(weekly_total, aes(x = week, y = total_submissions, color = status, group = status)) +
  geom_line(linewidth = 1.2) +
  geom_point(size = 2) +
  geom_vline(xintercept = as.numeric(manual_text_dates),
             color = "gray50", linetype = "dashed", alpha = 0.7) +
  labs(
    title = "Weekly Total Submissions",
    subtitle = "Standard vs. Super Observers (11/21/2023–12/10/2024)",
    x = "Week",
    y = "Total Submissions",
    color = "Observer Status"
  ) +
  scale_x_datetime(
    date_labels = "%b-%d",
    date_breaks = "2 weeks",
    sec.axis = dup_axis(
      breaks = adjusted_text_breaks,
      labels = format(manual_text_dates, "%b-%d"),
      name = "Texts Sent"
    )
  ) +
  theme_minimal() +
  theme(
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank(),
    panel.background = element_rect(fill = "white"),
    plot.background = element_rect(fill = "white"),
    axis.text.x.bottom = element_text(angle = 45, hjust = 1),
    axis.text.x.top = element_text(angle = 60, hjust = 1, vjust = 1, family = "serif"),
    axis.title.x.top = element_text(family = "serif", face = "bold")
  )

# Save weekly plot
ggsave("weekly_total_submissions_filtered.png", weekly_plot_total, width = 12, height = 6, dpi = 300)