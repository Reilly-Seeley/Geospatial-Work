####################################################################################
####################### Likert Statement Similarity Analysis ####################### 
####################################################################################

# 1. Reads survey responses, pivots statements into long format, and converts Likert responses to numeric.
# 2. Runs Mann–Whitney U tests per statement, saves significantly different statements to CSV.
# 3. Computes median and IQR by group, flags high-similarity statements, and saves full similarity table.
# 4. Generates a dumbbell plot of median responses for highly similar statements and saves it as PNG.

# Import data
responses <- read.csv("ResponseData_Edited.csv", stringsAsFactors = FALSE)

# Assign Observer Status
responses <- responses %>%
  mutate(Observer_Status = case_when(
    Collector_ID == 433931884 ~ "Super",
    Collector_ID == 433931340 ~ "Standard",
    TRUE ~ "Unknown"
  ))

# Pivot data longer
responses_long <- responses %>%
  pivot_longer(
    cols = starts_with("Statement_"),
    names_to = "Statement",
    values_to = "Response"
  ) %>%
  filter(!is.na(Response), Response != "")

# Define Likert scale
likert_scale <- c(
  "Strongly Disagree" = 1,
  "Disagree" = 2,
  "Disagree somewhat" = 3,
  "Neither agree nor disagree" = 4,
  "Agree somewhat" = 5,
  "Agree" = 6,
  "Strongly Agree" = 7
)

# Convert responses to numeric
responses_long <- responses_long %>%
  mutate(Response_Numeric = likert_scale[Response])

# Add Statement Text
statement_text <- data.frame(
  Statement = paste0("Statement_", 1:24),
  Statement_Text = c(
    "I have gained new knowledge about the project content since discovering MROS",
    "My work combined with other observers makes a meaningful impact in MROS research",
    "I can personally achieve something through my work with MROS",
    "I am satisfied with how MROS has increased or sustained my interest in science",
    "I have acquired new scientific skills since becoming involved with MROS",
    "I am interested in applying scientific knowledge or methods related to MROS in my own personal work beyond my participation in data collection",
    "My attitude towards the science has changed, allowing me to have more trust in the scientific process since becoming involved with MROS",
    "I am motivated to participate in this project long-term",
    "I wish to communicate with other MROS users regarding data collection",
    "I am able to explain the MROS mission and my role in it",
    "I am aware of MROS-related publications",
    "MROS has helped me understand how scientific results are generated",
    "I am satisfied with the amount of input I receive from MROS on their work with citizen science data",
    "I wish to receive more updates on the results of MROS research (e.g., new report-backs, summaries of research, etc.)",
    "I am satisfied with the report-backs for observers on the MROS website and feel they are good resources for learning about the project",
    "I am satisfied with the amount of recognition I receive for my work as a citizen scientist through MROS",
    "My involvement in MROS or climate change-focused participatory science programs makes me feel like I am part of a larger environmental stewardship movement",
    "I wish to know more about how MROS project results have a role in political and societal decision-making processes",
    "I wish there was a competitive component to data collection, like a public leaderboard display through the year",
    "My involvement with MROS has helped me better understand the local environment and its relationship to the larger climate system",
    "I trust that data collected at a local scale can effectively inform decisions at broader scales (e.g., regional, national)",
    "The Rocky Mountains are the headwaters for major river systems that impact multiple regions in the U.S., including the Colorado, Missouri, and Columbia Rivers. I am aware of how these river systems contribute to water supply and environmental health beyond the Rocky Mountain region",
    "My involvement with MROS has made me feel more connected to the environmental conditions (such as rain and snow) that impact the Rocky Mountain region and contribute to the greater climate system",
    "I care about these environmental factors because they affect my local community"
  )
)

# Join statement text
responses_long <- responses_long %>%
  left_join(statement_text, by = "Statement")

# Compute Mann-Whitney U tests and effect size
similarity_stats <- responses_long %>%
  filter(Observer_Status %in% c("Super", "Standard")) %>%
  group_by(Statement, Statement_Text) %>%
  wilcox_test(Response_Numeric ~ Observer_Status, exact = FALSE) %>%
  add_significance() %>%
  mutate(effect_size_r = abs(statistic / sqrt(n1 + n2))) %>%
  arrange(effect_size_r)

# Save ALL significantly DIFFERENT statements (p < 0.05)
significantly_different_statements <- similarity_stats %>%
  filter(p < 0.05) %>%
  arrange(p)

write.csv(significantly_different_statements, "Significantly_Different_Statements.csv", row.names = FALSE)

median_iqr_stats <- responses_long %>%
  filter(Observer_Status %in% c("Super", "Standard")) %>%
  group_by(Statement, Statement_Text, Observer_Status) %>%
  summarize(
    Median = median(Response_Numeric),
    IQR = IQR(Response_Numeric)
  ) %>%
  pivot_wider(names_from = Observer_Status, values_from = c(Median, IQR)) %>%
  mutate(
    Median_Difference = abs(Median_Super - Median_Standard),
    IQR_Overlap = (pmin(Median_Super + IQR_Super/2, Median_Standard + IQR_Standard/2) -
                     pmax(Median_Super - IQR_Super/2, Median_Standard - IQR_Standard/2)),
    High_Similarity = (Median_Difference <= 0.5) & (IQR_Overlap > 0)
  ) %>%
  arrange(Median_Difference)

# View table
print(median_iqr_stats, n=Inf)

# Save the complete table
write.csv(median_iqr_stats, "Median_IQR_Similarity.csv", row.names = FALSE)

# Select statements with highest similarity
high_similarity_plot_data <- median_iqr_stats %>%
  filter(High_Similarity == TRUE)

# Dumbbell plot for medians
dumbbell_plot <- ggplot(high_similarity_plot_data, 
                        aes(y = reorder(Statement_Text, Median_Standard),
                            x = Median_Standard, 
                            xend = Median_Super)) +
  geom_dumbbell(color = "#a3c4dc", 
                size_x = 3, size_xend = 3, 
                colour_x = "#0e668b", colour_xend = "#f09819") +
  scale_x_continuous(breaks = 1:7, labels = names(likert_scale), limits=c(1,7)) +
  labs(title = "Similarity between Observer Groups (Median Response)",
       x = "Median Likert Response",
       y = "Statement",
       caption = "Blue = Standard | Orange = Super") +
  theme_minimal(base_size = 12) +
  theme(axis.text.y = element_text(size = 8))

# Save 
ggsave("Dumbbell_Plot_High_Similarity.png", dumbbell_plot, 
       width = 12, height = 8, dpi = 300, bg = "white")