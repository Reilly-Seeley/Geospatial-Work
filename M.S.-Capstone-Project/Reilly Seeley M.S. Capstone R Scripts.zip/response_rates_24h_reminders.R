####################################################################################
################### 24-Hour Response Rates After Reminder Texts ####################
####################################################################################

# 1. Reads cleaned reminder-text and observation logs, converting timestamps to America/Denver.
# 2. Calculates each group’s unique user response rate within 24 hours of each reminder date.
# 3. Plots and saves a grouped bar chart of 24-hour submission rates (response_rates_bar_chart.png).

# Load datasets
texts <- read_csv("cleaned_texts_co.csv") %>%
  mutate(send_datetime_local = with_tz(ymd_hms(send_datetime), "America/Denver"))

submissions <- read_csv("cleaned_observations.csv") %>%
  mutate(datetime_submitted = ymd_hms(datetime_submitted))

# Corrected manual definition of text alert dates explicitly (2023-2024)
manual_text_dates <- as_datetime(c(
  "2023-12-26", "2024-01-05", "2024-02-02", "2024-02-09", 
  "2024-03-03", "2024-03-13", "2024-04-19", "2024-05-07", 
  "2024-10-30", "2024-11-05", "2024-11-08"
), tz = "America/Denver")

# Calculate response rates (excluding 'Overall')
response_rates <- tibble(send_datetime_local = manual_text_dates) %>%
  rowwise() %>%
  mutate(
    `Standard-Observers` = submissions %>%
      filter(datetime_submitted >= send_datetime_local, datetime_submitted <= send_datetime_local + hours(24), status == "standard-observer") %>%
      distinct(user_ID) %>%
      nrow() / submissions %>% filter(status == "standard-observer") %>% distinct(user_ID) %>% nrow() * 100,
    
    `Super-Observers` = submissions %>%
      filter(datetime_submitted >= send_datetime_local, datetime_submitted <= send_datetime_local + hours(24), status == "super-observer") %>%
      distinct(user_ID) %>%
      nrow() / submissions %>% filter(status == "super-observer") %>% distinct(user_ID) %>% nrow() * 100
  ) %>%
  pivot_longer(cols = c("Standard-Observers", "Super-Observers"),
               names_to = "Response Rate Type",
               values_to = "Response Rate")

# Ensure dates are ordered chronologically
response_rates$send_datetime_local <- factor(format(response_rates$send_datetime_local, "%b-%d-%Y"), 
                                             levels = unique(format(manual_text_dates, "%b-%d-%Y")))

# Bar chart visualization with specified colors (excluding 'Overall')
response_rates_plot <- ggplot(response_rates, aes(x = send_datetime_local, y = `Response Rate`, fill = `Response Rate Type`)) +
  geom_bar(stat = "identity", position = position_dodge()) +
  scale_fill_manual(values = c("Super-Observers" = "turquoise", "Standard-Observers" = "red")) +
  labs(
    title = "Observer Submission Rates within 24 Hours of Reminder",
    subtitle = "Comparison Across Observer Groups",
    x = "Reminder Dates",
    y = "Submission Rate (%)",
    fill = "Response Rates"
  ) +
  theme_minimal(base_size = 12) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank(),
    panel.background = element_rect(fill = "white"),
    plot.background = element_rect(fill = "white")
  )

# Display the plot
print(response_rates_plot)

# Save the plot
ggsave("response_rates_bar_chart.png", response_rates_plot, width = 12, height = 6, dpi = 300)
