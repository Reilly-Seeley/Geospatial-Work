####################################################################################
################ TPB-Informed Likert Significance & Means Analysis #################
####################################################################################

# 1. Reads survey responses, assigns Observer_Group, pivots statements into long format, and converts to numeric Likert scores.
# 2. Performs Mann–Whitney U tests per statement, computes group means, and filters for significant differences.
# 3. Maps each significant statement to its TPB construct and saves the results to Final_SignificantStatements_Means.csv.

# Load dataset 
data <- read.csv("ResponseData_Edited.csv")

# Define observer groups 
data$Observer_Group <- ifelse(data$Collector_ID == 433931884, "Super", "Standard")

# Transform data into long format and numeric values
long_data <- data %>%
  pivot_longer(cols = starts_with("Statement_"),
               names_to = "Statement",
               values_to = "Response") %>%
  mutate(Response_Numeric = case_when(
    Response == "Strongly Agree" ~ 1, Response == "Agree" ~ 2, Response == "Agree somewhat" ~ 3,
    Response == "Neither agree nor disagree" ~ 4, Response == "Disagree somewhat" ~ 5,
    Response == "Disagree" ~ 6, Response == "Strongly Disagree" ~ 7, TRUE ~ NA_real_
  )) %>% 
  filter(!is.na(Response_Numeric))

# Perform Mann-Whitney U tests
tests <- long_data %>%
  group_by(Statement) %>%
  summarise(
    U_Value = wilcox.test(Response_Numeric ~ Observer_Group, exact = FALSE)$statistic,
    p_value = round(wilcox.test(Response_Numeric ~ Observer_Group, exact = FALSE)$p.value,4),
    Mean_Super = mean(Response_Numeric[Observer_Group == "Super"], na.rm=TRUE),
    Mean_Standard = mean(Response_Numeric[Observer_Group == "Standard"], na.rm=TRUE)
  ) %>%
  mutate(Significance=case_when(
    p_value<0.05 & Mean_Super<Mean_Standard~"Super observers more likely to agree",
    p_value<0.05 & Mean_Super>Mean_Standard~"Standard observers more likely to agree",
    TRUE~"No significant difference")) %>%
  filter(Significance!="No significant difference") %>%
  mutate(TPB_Construct=case_when(
    Statement %in% c("Statement_1","Statement_4","Statement_7","Statement_12","Statement_16","Statement_17")~"Attitude Toward the Behavior",
    Statement %in% c("Statement_9","Statement_10","Statement_11","Statement_15","Statement_18","Statement_19")~"Subjective Norms and Social Influence",
    Statement %in% c("Statement_3","Statement_5","Statement_6","Statement_20","Statement_21")~"Perceived Behavioral Control",
    Statement %in% c("Statement_2","Statement_8","Statement_13","Statement_14","Statement_22","Statement_23","Statement_24")~"Behavioral Intention"
  )) %>%
  arrange(factor(TPB_Construct,levels=c("Attitude Toward the Behavior","Subjective Norms and Social Influence",
                                        "Perceived Behavioral Control","Behavioral Intention")), p_value)

# Save to CSV
write.csv(tests,"Final_SignificantStatements_Means.csv",row.names=FALSE)
