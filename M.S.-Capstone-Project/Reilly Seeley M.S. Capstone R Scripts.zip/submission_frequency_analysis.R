####################################################################################
################ Observer Submission Frequency Statistical Analysis ################
####################################################################################

# 1. Computes each user’s participation span and average submissions per week.
# 2. Performs a Wilcoxon rank-sum test to compare submission frequency between standard and super observers.
# 3. Prints the test output and a clear interpretation based on the p-value.

# Load observation data
observations <- read_csv("cleaned_observations.csv")

# Calculate each observer's participation window and total observations
observer_summary <- observations %>%
  mutate(submission_date = as.Date(datetime_submitted)) %>%
  group_by(user_ID, status) %>%
  summarise(
    participation_days = as.numeric(max(submission_date) - min(submission_date)) + 1,
    total_submissions = n(),
    .groups = 'drop'
  )

# Calculate weekly submission frequency
observer_summary <- observer_summary %>%
  mutate(
    participation_weeks = if_else(participation_days >= 7, participation_days / 7, 1),
    avg_submissions_per_week = total_submissions / participation_weeks
  )

# Mann-Whitney U (Wilcoxon) test to check for significance between groups
wilcox_test_result <- wilcox.test(
  avg_submissions_per_week ~ status, 
  data = observer_summary, 
  exact = FALSE
)

# Output the results
print(wilcox_test_result)

# Interpret results clearly:
if (wilcox_test_result$p.value < 0.05) {
  cat("\nResult: There is a statistically significant difference in submission frequency between standard and super observers (p-value:",
      round(wilcox_test_result$p.value,4),").\n")
} else {
  cat("\nResult: There is no statistically significant difference in submission frequency between standard and super observers (p-value:",
      round(wilcox_test_result$p.value,4),").\n")
}
