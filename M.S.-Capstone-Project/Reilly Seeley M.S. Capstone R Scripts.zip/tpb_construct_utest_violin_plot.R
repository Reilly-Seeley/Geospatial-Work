####################################################################################
############# TPB Construct U-Test & Violin Plot with Mean Annotations #############
####################################################################################

# 1. Loads survey data, reshapes into long format with numeric Likert scores, and assigns Observer_Group.
# 2. Maps each statement to its TPB construct, computes construct-level means.
# 3. Runs Mann–Whitney U tests per TPB construct, saves results table as a PNG.
# 4. Creates and annotates a violin+boxplot of responses by TPB construct and observer group.

# Load dataset
data <- read.csv("ResponseData_Edited.csv")

# Define observer groups
data$Observer_Group <- ifelse(data$Collector_ID == 433931884, "Super", "Standard")

# Pivot to long format and numeric conversion
long_data <- data %>%
  pivot_longer(cols = starts_with("Statement_"),
               names_to = "Statement",
               values_to = "Response") %>%
  mutate(Response_Numeric = case_when(
    Response == "Strongly Agree" ~ 1,
    Response == "Agree" ~ 2,
    Response == "Agree somewhat" ~ 3,
    Response == "Neither agree nor disagree" ~ 4,
    Response == "Disagree somewhat" ~ 5,
    Response == "Disagree" ~ 6,
    Response == "Strongly Disagree" ~ 7,
    TRUE ~ NA_real_
  )) %>%
  filter(!is.na(Response_Numeric))

# Explicitly update TPB construct definitions based on your final provided table
long_data <- long_data %>%
  mutate(TPB_Construct = case_when(
    Statement %in% c("Statement_1", "Statement_4", "Statement_7", "Statement_12", "Statement_16", "Statement_17") ~ "Attitude Toward the Behavior",
    Statement %in% c("Statement_9", "Statement_10", "Statement_11", "Statement_15", "Statement_18", "Statement_19") ~ "Subjective Norms and Social Influence",
    Statement %in% c("Statement_3", "Statement_5", "Statement_6", "Statement_20", "Statement_21") ~ "Perceived Behavioral Control",
    Statement %in% c("Statement_2", "Statement_8", "Statement_13", "Statement_14", "Statement_22", "Statement_23", "Statement_24") ~ "Behavioral Intention",
    TRUE ~ NA_character_
  )) %>%
  filter(!is.na(TPB_Construct))

# Calculate means for annotations
means_data <- long_data %>%
  group_by(TPB_Construct, Observer_Group) %>%
  summarise(Mean_Response = mean(Response_Numeric, na.rm = TRUE))

# Run Mann-Whitney U Tests calculated per TPB Construct
test_results <- long_data %>%
  group_by(TPB_Construct) %>%
  summarise(
    U_Value = wilcox.test(Response_Numeric ~ Observer_Group)$statistic,
    p_value = wilcox.test(Response_Numeric ~ Observer_Group)$p.value,
    Median_Super = median(Response_Numeric[Observer_Group == "Super"]),
    Median_Standard = median(Response_Numeric[Observer_Group == "Standard"])
  ) %>%
  mutate(Significance = case_when(
    p_value < 0.05 & Median_Super < Median_Standard ~ "Super observers more likely to agree (95% confidence)",
    p_value < 0.05 & Median_Super > Median_Standard ~ "Standard observers more likely to agree (95% confidence)",
    TRUE ~ "No significant difference"
  )) %>%
  mutate(p_value = round(p_value, 4)) %>%
  select(TPB_Construct, U_Value, p_value, Significance)

# Save Mann-Whitney results table
results_table <- tableGrob(test_results, rows = NULL)
ggsave("TPB_Utest_Results_Updated.png", results_table, width = 9, height = 3, dpi = 300)

# Violin plot explicitly adjusted
violin_plot <- ggplot(long_data, aes(x = TPB_Construct, y = Response_Numeric, fill = Observer_Group)) +
  geom_violin(trim = FALSE, alpha = 0.6, position = position_dodge(0.9), color = "grey30") +
  geom_boxplot(width = 0.1, position = position_dodge(0.9),
               outlier.shape = NA, linewidth = 0.8, color = "black", alpha = 0.8) +
  scale_fill_manual(values = c("Standard" = "red", "Super" = "blue")) +
  scale_y_reverse(breaks = 1:7,
                  labels = c("Strongly Agree (1)", "Agree (2)", "Agree somewhat (3)",
                             "Neutral (4)", "Disagree somewhat (5)", "Disagree (6)", "Strongly Disagree (7)")) +
  labs(title = "Distribution of Survey Responses by TPB Construct and Observer Group",
       x = NULL,
       y = "Likert Response",
       fill = "Observer Group") +
  theme_bw() +
  theme(plot.background = element_rect(fill = "white"),
        axis.text.x = element_text(angle = 45, hjust = 1, size = 12),
        axis.title.y = element_text(face = "bold", size = 14),
        plot.title = element_text(size = 20, face = "bold", hjust = 0.5),
        legend.title = element_text(face = "bold", size = 14),
        legend.text = element_text(size = 12),
        plot.margin = margin(t = 30, r = 10, b = 40, l = 10)) +
  # Explicit adjustment of mean values at y = 7.7
  geom_text(data = means_data,
            aes(x = TPB_Construct, y = 9.0,
                label = paste0("μ = ", round(Mean_Response, 2)), group = Observer_Group),
            position = position_dodge(width = 0.9),
            size = 4.5,
            fontface = "bold",
            color = "black") +
  # Explicit adjustment of "TPB Construct" label at y = -0.5
  annotate("text", x = 2.5, y = -1.0, label = "TPB Construct", fontface = "bold", size = 5)

# Save the final adjusted plot
ggsave("Final_TPB_ViolinPlot.png", violin_plot, width = 12, height = 7, dpi = 300)
